<?php
// Nabrijan Automatic Deployment Extractor
$rootTarget = dirname(__DIR__);
$zipPath = $rootTarget . '/deploy.zip';

if (!file_exists($zipPath)) {
    $zipPath = __DIR__ . '/deploy.zip';
}

if (!file_exists($zipPath)) {
    die("ERROR: deploy.zip not found at $zipPath");
}

$zip = new ZipArchive();
if ($zip->open($zipPath) === TRUE) {
    $zip->extractTo($rootTarget);
    $zip->close();
    echo "SUCCESS: Automatically extracted deploy.zip into $rootTarget";
} else {
    echo "ERROR: Could not open $zipPath";
}
